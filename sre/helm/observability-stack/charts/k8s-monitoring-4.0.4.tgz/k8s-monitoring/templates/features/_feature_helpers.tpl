{{- define "features.list" }}
- annotationAutodiscovery
- applicationObservability
- autoInstrumentation
- clusterMetrics
- clusterEvents
- costMetrics
- hostMetrics
- nodeLogs
- podLogsViaLoki
- podLogsViaOpenTelemetry
- podLogsViaKubernetesApi
- podLogsObjects
- profilesReceiver
- profiling
- prometheusOperatorObjects
- integrations
- selfReporting
{{- end }}

{{- define "features.list.enabled" }}
{{- range $feature := ((include "features.list" .) | fromYamlArray ) }}
  {{- if eq (include (printf "features.%s.enabled" $feature) $) "true" }}
- {{ $feature }}
  {{- end }}
{{- end }}
{{- end }}
